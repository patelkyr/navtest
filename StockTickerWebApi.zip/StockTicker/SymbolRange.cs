﻿namespace StockTicker
{
    /// <summary>
    /// Ticker range for randon pricing.
    /// </summary>
    public class TickerPriceRange
    {
        public int Min { get; set; }
        public int Max { get; set; }
    }
}