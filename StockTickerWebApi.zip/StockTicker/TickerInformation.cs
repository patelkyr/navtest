﻿namespace StockTicker
{
    /// <summary>
    /// Data structure to store supported ticker information
    /// </summary>
    public class TickerInformation
    {
        public TickerInformation(TickerPriceRange range)
        {
            Range = range;
        }

        public TickerPriceRange Range { get; set; }
    }
}