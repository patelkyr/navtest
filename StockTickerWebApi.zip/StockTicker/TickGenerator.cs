﻿using System;
using System.Collections.Generic;

namespace StockTicker
{
    /// <summary>
    /// Generates Ticks based on the min and max ranges provided.
    /// </summary>
    public static class TickGenerator
    {
        private static Dictionary<string, TickerInformation> tickers;

        private static Random randomNumberGenerator;

        static TickGenerator()
        {
            tickers = new Dictionary<string, TickerInformation>();
            tickers.Add("Stock1", new TickerInformation(new TickerPriceRange { Min = 240, Max = 270 }));
            tickers.Add("Stock2", new TickerInformation(new TickerPriceRange { Min = 180, Max = 210 }));
        }

        public static void Initialize()
        {
            randomNumberGenerator = new Random(Convert.ToInt32(DateTime.Now.ToString("HHmmss")));

            var tickerArray = new string[tickers.Count];
            tickers.Keys.CopyTo(tickerArray, 0);
            TickerNames = new List<string>(tickerArray);
        }

        /// <summary>
        /// Gets a list of supported ticker names
        /// </summary>
        public static List<string> TickerNames { get; private set; }

        /// <summary>
        /// Generates ticker price
        /// </summary>
        /// <param name="tickerName">Ticker symbol name e.g. Stock1</param>
        /// <returns>Ticker information that includes Name, Price and TimeStamp its generated on</returns>
        public static Ticker GenerateTick(string tickerName)
        {
            if (tickers.TryGetValue(tickerName, out TickerInformation tickerInfo))
            {
                var tickerPrice = randomNumberGenerator.Next(tickerInfo.Range.Min, tickerInfo.Range.Max);

                var tiker = new Ticker
                {
                    Symbol = tickerName,
                    Price = tickerPrice,
                    GeneratedOn = DateTime.Now
                };

                return tiker;
            }

            return null;
        }
    }
}