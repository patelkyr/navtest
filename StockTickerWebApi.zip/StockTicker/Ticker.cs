﻿using System;
using System.Runtime.Serialization;

namespace StockTicker
{
    [DataContract]
    public class Ticker
    {
        [DataMember]
        public string Symbol { get; set; }

        [DataMember]
        public double Price { get; set; }

        [DataMember]
        public DateTime GeneratedOn { get; set; }
    }
}