﻿using StockTickerWebApi.Handlers;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace StockTickerWebApi.Controllers
{
    public class UnsubscribeController : ApiController
    {
        // GET: api/Unsubscribe
        public IEnumerable<string> Get()
        {
            return AppStorage.Subscribers.Select(s => s.ToString()).ToList();
        }

        // GET: api/Unsubscribe/5
        public string Get(int id)
        {
            return "value";
        }

        // POST: api/Unsubscribe
        public void Post([FromBody]string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                throw new HttpResponseException(Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Client Endpoint and ticker Name has to be provided e.g. localhost:90,Stock1 to subscribe"));
            }

            var splitValue = value.Split(new[] { ',' });
            if (splitValue.Length != 2)
            {
                throw new HttpResponseException(Request.CreateErrorResponse(HttpStatusCode.BadRequest, "Client Endpoint and ticker Name has to be provided e.g. localhost:90,Stock1 to subscribe"));
            }

            Subscriber s = new Subscriber(splitValue[0], splitValue[1]);
            AppStorage.RemoveSubscriber(s);
            TickerPublisher.TryStop();
        }

        // PUT: api/Unsubscribe/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Unsubscribe/5
        public void Delete(int id)
        {
        }
    }
}