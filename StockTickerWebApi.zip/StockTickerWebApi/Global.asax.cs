﻿using StockTicker;
using StockTickerWebApi.Handlers;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace StockTickerWebApi
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            TickGenerator.Initialize();
            AppStorage.Initialize();

            //ToDo: Read interval from configuration
            TickerPublisher.Initialize(1);
            TickerPublisher.Start();
        }
    }
}