﻿using Newtonsoft.Json;
using StockTicker;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace StockTickerWebApi.Handlers
{
    /// <summary>
    /// Publisher that pushes ticker information to subscribed clients.
    /// </summary>
    public static class TickerPublisher
    {
        private static bool isTicking = false;
        private static int _tokenGenerationInterval = -1;

        private static object objLock = new object();

        /// <summary>
        /// Initialize the publisher.
        /// </summary>
        /// <param name="tokenGenerationInterval">Ticker generation interval in seconds</param>
        public static void Initialize(int tokenGenerationInterval)
        {
            _tokenGenerationInterval = tokenGenerationInterval;
        }

        /// <summary>
        /// Start publisher.
        /// </summary>
        public static async void Start()
        {
            if (_tokenGenerationInterval == -1)
                throw new Exception("Cannot start ticker generation before calling Initialize");

            if (isTicking) { return; }
            //Generation is to started as soon as 1 ticker is subscribe. If its already true, no need to call it again.
            //if (isTicking == false)
            //{
            //    lock (objLock)
            //    {
            //        //Double checking to make it thread safe, similar to singleton class initialization.
            //        if (isTicking == false)
            //        {
            //            isTicking = true;

            //            GenerateTicksAndPublish().ConfigureAwait(false);
            //        }
            //    }
            //}
            isTicking = true;

            GenerateTicksAndPublish().ConfigureAwait(false);
        }

        /// <summary>
        /// Try and stop publisher. This is called each time a client is unsubscribed. But it only stops when there are no more subscriptions.
        /// </summary>
        public static void TryStop()
        {
            if (isTicking)
            {
                lock (objLock)
                {
                    if (isTicking)
                    {
                        //If all tickers are unsubscribed, stop generating randomg numbers.
                        if (AppStorage.Subscribers.Count(s => s.Value.Count != 0) == 0)
                        {
                            isTicking = false;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Generates tickers and publishes to clients
        /// </summary>
        private static async Task GenerateTicksAndPublish()
        {
            while (isTicking)
            {
                foreach (var tickers in AppStorage.Subscribers.Where(s => s.Value.Count > 0))
                {
                    //Ticker has subscribers, then Generate and Push Tick information
                    if (tickers.Value.Count > 0)
                    {
                        var tickerInformation = TickGenerator.GenerateTick(tickers.Key);
                        await PublishTicker(tickerInformation, tickers.Value).ConfigureAwait(false);
                    }
                }

                await Task.Delay(new TimeSpan(0, 0, _tokenGenerationInterval));
            }
        }

        /// <summary>
        /// Publishes ticker information to client
        /// </summary>
        /// <param name="tickerInformation"></param>
        /// <param name="clientEndpoints"></param>
        private static async Task PublishTicker(Ticker tickerInformation, List<string> clientEndpoints)
        {
            foreach (var endPoint in clientEndpoints)
            {
                var client = new HttpClient()
                {
                    BaseAddress = new Uri(endPoint)
                };

                HttpContent c = new StringContent(JsonConvert.SerializeObject(tickerInformation));
                c.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

                HttpResponseMessage result = await client.PostAsync("api/Main/", c);
            }
        }
    }
}