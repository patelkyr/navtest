﻿namespace StockTickerWebApi.Handlers
{
    public class Subscriber
    {
        public string Endpoint { get; set; }

        public string TickerName { get; set; }

        public Subscriber(string endPoint, string tickerName)
        {
            Endpoint = endPoint;
            TickerName = tickerName;
        }

        public override string ToString()
        {
            return $"{Endpoint}: {TickerName}";
        }
    }
}