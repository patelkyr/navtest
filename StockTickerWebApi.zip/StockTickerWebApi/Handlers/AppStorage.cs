﻿using StockTicker;
using System.Collections.Generic;

namespace StockTickerWebApi.Handlers
{
    /// <summary>
    /// Class that stores the subscriber information. To make it easier, subscriber endpoints are stored per ticker name.
    /// e.g. multiple clients can subscribe to 1 ticker so the key to the dictionary will be ticker name.
    /// Value of the dictionary will contain a list of clients (endpoints) that subscribed to the ticker.
    /// </summary>
    public static class AppStorage
    {
        public static object objLock = new object();

        public static Dictionary<string, List<string>> Subscribers { get; private set; }

        static AppStorage()
        {
            Subscribers = new Dictionary<string, List<string>>();

            foreach (var tickerName in TickGenerator.TickerNames)
            {
                Subscribers.Add(tickerName, new List<string>());
            }
        }

        public static void Initialize()
        {
        }

        /// <summary>
        /// Add a new subscriber
        /// </summary>
        /// <param name="subscriber"></param>
        public static void AddSubscriber(Subscriber subscriber)
        {
            lock (objLock)
            {
                if (Subscribers.TryGetValue(subscriber.TickerName, out List<string> endPoints))
                {
                    if (!endPoints.Contains(subscriber.Endpoint))
                    {
                        endPoints.Add(subscriber.Endpoint);

                        Subscribers[subscriber.TickerName] = endPoints;
                    }
                }
            }
        }

        /// <summary>
        /// Remove subscription. Whenever a subscriber is removed, the ticker publisher TryStop is called.
        /// TickerPublisher.TryStop only stops when there are no more publishers for any tickers.
        /// </summary>
        /// <param name="subscriber"></param>
        public static void RemoveSubscriber(Subscriber subscriber)
        {
            lock (objLock)
            {
                if (Subscribers.TryGetValue(subscriber.TickerName, out List<string> endPoints))
                {
                    if (endPoints.Contains(subscriber.Endpoint))
                    {
                        endPoints.Remove(subscriber.Endpoint);

                        Subscribers[subscriber.TickerName] = endPoints;
                    }
                }

                TickerPublisher.TryStop();
            }
        }
    }
}