﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows.Forms;
using System.Configuration;
using System.Web.Http.SelfHost;
using System.Web.Http;
using System.Net.Http;
using Newtonsoft.Json;

namespace StockClient
{
    public partial class StockForm : Form
    {
        public HttpSelfHostServer config;
        public static readonly IList<StockEntity> StockList = new List<StockEntity>();
        public StockForm()
        {
            //SetupSelfHostServer();
            config = SetHttpSelfHost();
            InitializeComponent();
            DisableButtons();
        }

        public StockEntity stockEntity { get; set; }

        private void btnSubscribe_Click(object sender, EventArgs e)
        {
            //call to the api           

            var checkedButton = groupBox1.Controls.OfType<RadioButton>()
                                      .FirstOrDefault(r => r.Checked);
            if (string.IsNullOrEmpty(Convert.ToString(checkedButton)))
            {
                MessageBox.Show("Please select stock from the list!!!");
                return;
            }
            config.OpenAsync().Wait();
            PopulateStockData(checkedButton.Text.ToString());
        }

        private void PopulateStockData(string stockName)
        {
            //SetupSelfHostServer();
            Subscribe();
            EnableButtons();
            btnSubscribe.Enabled = false;
            groupBox1.Enabled = false;
        }

        private void btnUnsubscribe_Click(object sender, EventArgs e)
        {
            UnSubscribe();
            config.CloseAsync().Wait();
            config.Dispose();
            config.Configuration.Dispose();
            

            groupBox1.Enabled = true;
            btnSubscribe.Enabled = true;

            DisableButtons();
            StockList.Clear();            
        }

        private void buttonHistory_Click(object sender, EventArgs e)
        {
            
        }

        private void EnableButtons()
        {
            btnUnsubscribe.Enabled = true;
            
        }
        private void DisableButtons()
        {
            btnUnsubscribe.Enabled = false;            
        }

        private void StockForm_Load(object sender, EventArgs e)
        {

        }

        private void SetupSelfHostServer()
        {
            var endPointUrl = ConfigurationManager.AppSettings["selfHostEndPointUrl"].ToString();
            var url = string.Empty;
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    url = endPointUrl;
                    break;
                }
            }

            AppStorage.serverName = url;

            var config = new HttpSelfHostConfiguration(url);
            config.Routes.MapHttpRoute(
            name: "DefaultApi",
            routeTemplate: "api/{controller}/{id}",
            defaults: new { id = RouteParameter.Optional }
            );


            var json = GlobalConfiguration.Configuration.Formatters.JsonFormatter;
            json.SerializerSettings.DateTimeZoneHandling = Newtonsoft.Json.DateTimeZoneHandling.Utc;

            var s = new HttpSelfHostServer(config);
            s.OpenAsync().Wait();
        }

        private HttpSelfHostServer SetHttpSelfHost()
        {
            var endPointUrl = ConfigurationManager.AppSettings["selfHostEndPointUrl"].ToString();
            var url = string.Empty;
            IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                {
                    url = endPointUrl;

                    break;
                }
            }

            AppStorage.serverName = url;

            var config = new HttpSelfHostConfiguration(url);
            config.Routes.MapHttpRoute(
            name: "DefaultApi",
            routeTemplate: "api/{controller}/{id}",
            defaults: new { id = RouteParameter.Optional }
            );


            var json = GlobalConfiguration.Configuration.Formatters.JsonFormatter;
            json.SerializerSettings.DateTimeZoneHandling = Newtonsoft.Json.DateTimeZoneHandling.Utc;

            var s = new HttpSelfHostServer(config);
            return s;
        }

        private static async void Subscribe()
        {
            var client = new HttpClient()
            {
                BaseAddress = new Uri(ConfigurationManager.AppSettings["serverApiUrl"].ToString())
            };
            //Ticker msg = new Message(AppStorage.serverName, DateTime.Now);
            HttpContent c = new StringContent(JsonConvert.SerializeObject($"{ConfigurationManager.AppSettings["selfHostEndPointUrl"].ToString()},Stock1"));
            c.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

            HttpResponseMessage result = await client.PostAsync("api/Subscribe/", c);
            //Console.WriteLine("Subscription status: {0}", result.StatusCode);

        }

        private static async void UnSubscribe()
        {
            var client = new HttpClient()
            {
                BaseAddress = new Uri(ConfigurationManager.AppSettings["serverApiUrl"].ToString())
            };
            //Ticker msg = new Message(AppStorage.serverName, DateTime.Now);
            HttpContent c = new StringContent(JsonConvert.SerializeObject($"{ConfigurationManager.AppSettings["selfHostEndPointUrl"].ToString()},Stock1"));
            c.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");

            HttpResponseMessage result = await client.PostAsync("api/Unsubscribe/", c);
            Console.WriteLine("Subscription status: {0}", result.StatusCode);

            
        }
    }
}
