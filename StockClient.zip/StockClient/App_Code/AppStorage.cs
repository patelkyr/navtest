﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockClient
{
    public static class AppStorage
    {
        public static string serverName { get; set; }
    }
}
