﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Windows.Forms;

namespace StockClient
{
    public class MainController:ApiController
    {
        StockForm stk = new StockForm();
        public void Post([FromBody]Ticker ticker)
        {
            //stk.stockEntity.StockName = ticker.Symbol;
            //stk.stockEntity.StockPrice = Convert.ToDecimal(ticker.Price);
            //stk.stockEntity.StockPriceTime = ticker.GeneratedOn;
            Console.WriteLine("Stock Name: {0},Stock Price: {1}, Stock Time: {2}", ticker.Symbol,ticker.Price, ticker.GeneratedOn);
        }
    }
}
