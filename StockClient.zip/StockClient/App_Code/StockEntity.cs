﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StockClient
{
    public class StockEntity
    {
        public string StockName { get; set; }
        public decimal StockPrice { get; set; }
        public DateTime StockPriceTime { get; set; }
    }
}
