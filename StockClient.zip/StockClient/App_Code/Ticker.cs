﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace StockClient
{
    [DataContract]
    public class Ticker
    {
        [DataMember]
        public string Symbol { get; set; }

        [DataMember]
        public double Price { get; set; }

        [DataMember]
        public DateTime GeneratedOn { get; set; }
    }
}
