﻿namespace StockClient
{
    partial class StockForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSubscribe = new System.Windows.Forms.Button();
            this.btnUnsubscribe = new System.Windows.Forms.Button();
            this.radioStock1 = new System.Windows.Forms.RadioButton();
            this.radioStock2 = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblStockName = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSubscribe
            // 
            this.btnSubscribe.Location = new System.Drawing.Point(261, 37);
            this.btnSubscribe.Name = "btnSubscribe";
            this.btnSubscribe.Size = new System.Drawing.Size(173, 28);
            this.btnSubscribe.TabIndex = 0;
            this.btnSubscribe.Text = "Subscribe";
            this.btnSubscribe.UseVisualStyleBackColor = true;
            this.btnSubscribe.Click += new System.EventHandler(this.btnSubscribe_Click);
            // 
            // btnUnsubscribe
            // 
            this.btnUnsubscribe.Location = new System.Drawing.Point(261, 101);
            this.btnUnsubscribe.Name = "btnUnsubscribe";
            this.btnUnsubscribe.Size = new System.Drawing.Size(173, 28);
            this.btnUnsubscribe.TabIndex = 1;
            this.btnUnsubscribe.Text = "Unsubscribe";
            this.btnUnsubscribe.UseVisualStyleBackColor = true;
            this.btnUnsubscribe.Click += new System.EventHandler(this.btnUnsubscribe_Click);
            // 
            // radioStock1
            // 
            this.radioStock1.AutoSize = true;
            this.radioStock1.Location = new System.Drawing.Point(24, 19);
            this.radioStock1.Name = "radioStock1";
            this.radioStock1.Size = new System.Drawing.Size(59, 17);
            this.radioStock1.TabIndex = 2;
            this.radioStock1.TabStop = true;
            this.radioStock1.Text = "Stock1";
            this.radioStock1.UseVisualStyleBackColor = true;
            // 
            // radioStock2
            // 
            this.radioStock2.AutoSize = true;
            this.radioStock2.Location = new System.Drawing.Point(24, 58);
            this.radioStock2.Name = "radioStock2";
            this.radioStock2.Size = new System.Drawing.Size(59, 17);
            this.radioStock2.TabIndex = 3;
            this.radioStock2.TabStop = true;
            this.radioStock2.Text = "Stock2";
            this.radioStock2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioStock1);
            this.groupBox1.Controls.Add(this.radioStock2);
            this.groupBox1.Location = new System.Drawing.Point(26, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(200, 100);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Stock";
            // 
            // lblStockName
            // 
            this.lblStockName.AllowDrop = true;
            this.lblStockName.AutoSize = true;
            this.lblStockName.Location = new System.Drawing.Point(118, 266);
            this.lblStockName.Name = "lblStockName";
            this.lblStockName.Size = new System.Drawing.Size(0, 13);
            this.lblStockName.TabIndex = 10;
            this.lblStockName.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // StockForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(756, 755);
            this.Controls.Add(this.lblStockName);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnUnsubscribe);
            this.Controls.Add(this.btnSubscribe);
            this.Name = "StockForm";
            this.Text = "Stock Client";
            this.Load += new System.EventHandler(this.StockForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSubscribe;
        private System.Windows.Forms.Button btnUnsubscribe;
        private System.Windows.Forms.RadioButton radioStock1;
        private System.Windows.Forms.RadioButton radioStock2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblStockName;
    }
}

